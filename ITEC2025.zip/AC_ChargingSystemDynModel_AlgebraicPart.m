function Z=AC_ChargingSystemDynModel_AlgebraicPart(X,U,CharSysParamAlgebrPart)

x1=X(1,1);
x2=X(2,1);
x3=X(3,1);
x4=X(4,1);

u1=U(1,1);
u2=U(2,1);
u3=U(3,1);

m=CharSysParamAlgebrPart(1,1);
eta_inv=CharSysParamAlgebrPart(2,1);
eta_conv=CharSysParamAlgebrPart(3,1);
V_min=CharSysParamAlgebrPart(4,1);
V_max=CharSysParamAlgebrPart(5,1);

% algebraic equations
    % Calculate OCV from SOC
    V_oc = f_SOC(x4,V_max,V_min);
    
    % Calculate V_ch
    V_ch = V_oc + x3;
    
    % Calculate V_dc
    V_dc = V_ch/u3;
    
    % Calculate V_inv (inverter output voltage)
    V_inv_x = (1/m) * sqrt(3/8) * V_dc * u1;
    V_inv_y = (1/m) * sqrt(3/8) * V_dc * u2;
    
    % Calculate Idc
    I_dc = V_dc^(-1) * (x1 * V_inv_x + x2 * V_inv_y) * eta_inv;
    
    % Calculate Ich
    I_ch = V_ch^(-1) * I_dc * V_dc * eta_conv;

Z=[V_oc;V_ch;V_dc;V_inv_x;V_inv_y;I_dc;I_ch];