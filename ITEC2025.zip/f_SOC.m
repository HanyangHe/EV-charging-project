function OCV=f_SOC(SOC,V_max,V_min)

OCV=V_min + (V_max - V_min) * (log(1 + 99 * SOC) / log(100));
