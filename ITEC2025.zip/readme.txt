1.Run DisplayOCV_SOC.mlx will give you the VOC-SOC curve in the paper.
2.Run mdel_error_withDisturb.mlx and control_results_ITEC.mlx will load the saved results and plot the results figure in the paper.
3.If you want to re-simulate the process of the Physical model, NN model, and SINDy model based MPC, 
run the file Main_AC_DC_ChargingSystem.mlx, Main_AC_DC_ChargingSystem_ANN.mlx, and Main_AC_DC_ChargingSystem_SINDyIdeal.mlx.
If you do not want to curve the saved data of the paper, please set saveData=0 or change the file save path in the code.