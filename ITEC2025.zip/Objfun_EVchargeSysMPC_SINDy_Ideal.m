function cost=Objfun_EVchargeSysMPC_SINDy_Ideal(decisionV,d_box,deciPre,X0,Delta0,Coef_SINDy_Diff,Coef_SINDy_Algb,V_max,V_min,SOC0,SOCtarget,Voc90,dt,controlHorizon,predictionHorizon,MeasureVpccMag,VpccMag0)

w_Iac=0.1;
w_dU=0.5;
w_diL=0.1;
w_charge=2;
w_Vcb=1;
w_SOC=4;
w_SOCr=4;
w_u=4;
Alpha=4;

cost=0;
V_ch_ref=Voc90;

decisionV=reshape(decisionV,size(decisionV,1)/controlHorizon,controlHorizon);
U=repelem(decisionV, 1, d_box);% expand column of decisionV_u based on the element in d_box
Upre=[deciPre U(:,1:end-1)];

Delta=repmat(Delta0,1,predictionHorizon);

X(:,1)=X0;
xe(1,1)=0;

for i=1:predictionHorizon
    % modeling solving (1st-order Euler)
    % library_vector=candidateFuncPool_Ideal(X(:,i),U(:,i),Delta(:,i),V_max,V_min,2);
    % dotx=(library_vector*Coef_SINDy_Diff)';
    % X(:,i+1)=X(:,i)+dotx*dt;

    % modeling solving (2nd-order Euler)
    % library_vector=candidateFuncPool_Ideal(X(:,i),U(:,i),Delta(:,i),V_max,V_min,2);
    % dotx=(library_vector*Coef_SINDy_Diff)';
    % Xnext=X(:,i)+dotx*dt;
    % dot_xe=X(4,i)-SOCtarget;
    % 
    % library_vector=candidateFuncPool_Ideal(Xnext,U(:,i),Delta(:,i),V_max,V_min,2);
    % dotxnext=(library_vector*Coef_SINDy_Diff)';
    % X(:,i+1)=X(:,i)+(dotx+dotxnext)/2*dt;
    % dot_xe_next=Xnext(4,1)-SOCtarget;
    % xe(1,i+1)=xe(1,i)+(dot_xe+dot_xe_next)/2*dt;% integral error

    % model solving (ode4)
    [IncRate,~] = ode4_singleStep(X(:,i),U(:,i), Delta(:,i), dt, Coef_SINDy_Diff, V_max, V_min);
    X(:,i+1)=X(:,i)+IncRate*dt;
    dot_xe=X(4,i)-SOCtarget;
    xe(1,i+1)=xe(1,i)+(dot_xe)*dt;% integral error

    % output observe
    library_vector=candidateFuncPool_Ideal(X(:,i),U(:,i),Delta(:,i),V_max,V_min,1);
    Z(:,i)=(library_vector*Coef_SINDy_Algb)';
  
    % extract information
    SOC=X(4,i);
    I_ch = Z(7,i);
    V_ch = Z(2,i);
    V_oc = Z(1,i);

    if MeasureVpccMag==1
    VpccMag=sqrt(Delta(1,i)^2+Delta(2,i)^2);
    else
    VpccMag=VpccMag0;
    end
    m=1;
    Vdc_end=1/m*sqrt(8/3)*VpccMag;% assume Ex and Ey will give the max magnitude sqrt(Ex^2+Ey^2)=1
    d_0=0.95;
    d_end=min(V_ch_ref/Vdc_end,d_0);
    
    w=Weights_adjuster((SOC-SOC0)/(SOCtarget-SOC0),SOCtarget/SOCtarget,1,0,Alpha);
    
    % ---------state tracking------------
    cost=cost+w_SOCr*(X(4,i)-SOCtarget)^2;% track the target SOC
    cost=cost+w_SOCr*xe(1,i)^2;% integral of error

    % state traking at fully charge stage
    cost=cost+w_Vcb*(w)*(V_ch-V_oc)^2;% when fully charge, Vcb should be zero
    cost=cost+w*sqrt(X(1,i)^2+X(2,i)^2)*w_Iac;% reduce AC current magnitude when charging finished

    % tracking control for other variable
    cost=cost-w_charge*((1-w)*I_ch);% when fully charge, charging current should be zero

    % -------penalty of variation-------
    cost=cost+w_dU*sum((U(:,i)-Upre(:,i)).^2);% penalty of input change

    if i>1
        cost=cost+w_diL*sum((X(1:2,i)-X(1:2,i-1)).^2);% penalty of state1-2 (iL) change
    end

    % ------track the target U at steady state-------
    cost=cost+w_u*(w)*(sqrt(U(1,i)^2+U(2,i)^2)-1)^2;
    cost=cost+w_u*(w)*(d_end-U(3,i))^2;% track the target duty cycle
end

% terminal cost
cost=cost+w_SOC*(X(4,end)-SOCtarget)^2;% track the target SOC

function [IncRate,dotX] = ode4_singleStep(X, U, Delta, h, Coef_SINDy_Diff, V_max, V_min)
    % k1 = f(t, X, U1, D1);
    U1 = U;           % U(t)
    D1 = Delta;       % Delta(t)
    X1=X;
    k1 = (candidateFuncPool_Ideal(X1,U1,D1,V_max,V_min,2)*Coef_SINDy_Diff)';
    
    % k2 = f(t + 0.5*h, X + 0.5*h*k1, U2, D2);
    U2 = U;
    D2 = Delta;
    X2=X + 0.5*h*k1;
    k2 = (candidateFuncPool_Ideal(X2,U2,D2,V_max,V_min,2)*Coef_SINDy_Diff)';
    
    % k3 = f(t + 0.5*h, X + 0.5*h*k2, U2, D2);
    U3 = U2;
    D3 = D2;
    X3=X + 0.5*h*k2;
    k3 = (candidateFuncPool_Ideal(X3,U3,D3,V_max,V_min,2)*Coef_SINDy_Diff)';

    % k4 = f(t + h, X + h*k3, U3, D3);
    U4 = U;
    D4 = Delta;
    X4=X + h*k3;
    k4 = (candidateFuncPool_Ideal(X4,U4,D4,V_max,V_min,2)*Coef_SINDy_Diff)';

    IncRate =  (1/6) * (k1 + 2*k2 + 2*k3 + k4);
    dotX=k1;
end
end