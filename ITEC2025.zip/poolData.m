function yout = poolData(yin,nVars,polyorder,usesine)
% Copyright 2015, All Rights Reserved
% Code by Steven L. Brunton
% For Paper, "Discovering Governing Equations from Data: 
%        Sparse Identification of Nonlinear Dynamical Systems"
% by S. L. Brunton, J. L. Proctor, and J. N. Kutz
% Edit by Hanyang He at 2024
% add polynomial with higher order 6-10
% for the "GSINDy" paper

n = size(yin,1);

ind = 1;
% poly order 0
yout(:,ind) = ones(n,1);
ind = ind+1;

% poly order 1
for i=1:nVars
    yout(:,ind) = yin(:,i);
    ind = ind+1;
end

if(polyorder>=2)
    % poly order 2
    for i=1:nVars
        for j=i:nVars
            yout(:,ind) = yin(:,i).*yin(:,j);
            ind = ind+1;
        end
    end
end

if(polyorder>=3)
    % poly order 3
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k);
                ind = ind+1;
            end
        end
    end
end

if(polyorder>=4)
    % poly order 4
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l);
                    ind = ind+1;
                end
            end
        end
    end
end

if(polyorder>=5)
    % poly order 5
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    for m=l:nVars
                        yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l).*yin(:,m);
                        ind = ind+1;
                    end
                end
            end
        end
    end
end

if(polyorder>=6)
    % poly order 6
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    for m=l:nVars
                        for m1=m:nVars
                            yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l).*yin(:,m).*yin(:,m1);
                            ind = ind+1;
                        end
                    end
                end
            end
        end
    end
end

if(polyorder>=7)
    % poly order 7
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    for m=l:nVars
                        for m1=m:nVars
                            for m2=m1:nVars
                                yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l).*yin(:,m).*yin(:,m1).*yin(:,m2);
                                ind = ind+1;
                            end
                        end
                    end
                end
            end
        end
    end
end

if(polyorder>=8)
    % poly order 8
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    for m=l:nVars
                        for m1=m:nVars
                            for m2=m1:nVars
                                for m3=m2:nVars
                                    yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l).*yin(:,m).*yin(:,m1).*yin(:,m2).*yin(:,m3);
                                    ind = ind+1;
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

if(polyorder>=9)
    % poly order 9
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    for m=l:nVars
                        for m1=m:nVars
                            for m2=m1:nVars
                                for m3=m2:nVars
                                    for m4=m3:nVars
                                        yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l).*yin(:,m).*yin(:,m1).*yin(:,m2).*yin(:,m3).*yin(:,m4);
                                        ind = ind+1;
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

if(polyorder>=10)
    % poly order 10
    for i=1:nVars
        for j=i:nVars
            for k=j:nVars
                for l=k:nVars
                    for m=l:nVars
                        for m1=m:nVars
                            for m2=m1:nVars
                                for m3=m2:nVars
                                    for m4=m3:nVars
                                        for m5=m4:nVars
                                            yout(:,ind) = yin(:,i).*yin(:,j).*yin(:,k).*yin(:,l).*yin(:,m).*yin(:,m1).*yin(:,m2).*yin(:,m3).*yin(:,m4).*yin(:,m5);
                                            ind = ind+1;
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

if usesine>0
    for k=1:usesine
        yout = [yout sin(k*yin) cos(k*yin)];
    end
end

% yout = [yout exp(yin)];