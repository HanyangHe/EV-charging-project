function dotX=AnalyticalEVCSystemModel(Xmat,Umat,Delta_mat,CharSysParamDiffPart,CharSysParamAlgebrPart)

R=CharSysParamDiffPart(1,1);
L=CharSysParamDiffPart(2,1);
w0=CharSysParamDiffPart(3,1);
R_b=CharSysParamDiffPart(4,1);
C_b=CharSysParamDiffPart(5,1);
Q_max=CharSysParamDiffPart(6,1);

m=CharSysParamAlgebrPart(1,1);
eta_inv=CharSysParamAlgebrPart(2,1);
eta_conv=CharSysParamAlgebrPart(3,1);
V_min=CharSysParamAlgebrPart(4,1);
V_max=CharSysParamAlgebrPart(5,1);

% algebraic equations (no independent algebraic variable)
    % Calculate OCV from SOC
    V_oc = f_SOC(Xmat(4,:),V_max,V_min);
    
    % Calculate V_ch
    V_ch = V_oc + Xmat(3,:);
    
    % Calculate V_dc
    V_dc = V_ch./Umat(3,:);
    
    % Calculate V_inv (inverter output voltage)
    V_inv_x = (1/m) * sqrt(3/8) * V_dc .* Umat(1,:);
    V_inv_y = (1/m) * sqrt(3/8) * V_dc .* Umat(2,:);

    % Calculate Idc
    I_dc = V_dc.^(-1) .* (Xmat(1,:) .* V_inv_x + Xmat(2,:) .* V_inv_y) * eta_inv;
    
    % Calculate Ich
    I_ch = V_ch.^(-1) .* I_dc .* V_dc * eta_conv;

% ODE model
dotX1mat=-R/L*Xmat(1,:)+w0*Xmat(2,:)+1/L*Delta_mat(1,:)-1/L*(V_inv_x);
dotX2mat=-R/L*Xmat(2,:)-w0*Xmat(1,:)+1/L*Delta_mat(2,:)-1/L*(V_inv_y);
dotX3mat=C_b^(-1)*(I_ch-R_b^(-1)*Xmat(3,:));
dotX4mat=Q_max^(-1)*I_ch;

dotX=[dotX1mat;dotX2mat;dotX3mat;dotX4mat];