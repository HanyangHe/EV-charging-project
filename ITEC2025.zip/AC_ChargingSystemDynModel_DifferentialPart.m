function dotX=AC_ChargingSystemDynModel_DifferentialPart(X,Z,Delta,CharSysParamDiffPart)

x1=X(1,1);
x2=X(2,1);
x3=X(3,1);

delta1=Delta(1,1);
delta2=Delta(2,1);

R=CharSysParamDiffPart(1,1);
L=CharSysParamDiffPart(2,1);
w0=CharSysParamDiffPart(3,1);
R_b=CharSysParamDiffPart(4,1);
C_b=CharSysParamDiffPart(5,1);
Q_max=CharSysParamDiffPart(6,1);

% algebraic results
    % Calculate V_inv (inverter output voltage)
    V_inv_x = Z(4,1);
    V_inv_y = Z(5,1);
    
    % Calculate Ich
    I_ch = Z(7,1);

% differential equations
    % State derivatives
    x1_dot = (-R/L) * x1 + w0 * x2 + (1/L) * (delta1 - V_inv_x);
    x2_dot = (-R/L) * x2 - w0 * x1 + (1/L) * (delta2 - V_inv_y);
    x3_dot = C_b^(-1) * (I_ch - R_b^(-1) * x3);
    x4_dot = Q_max^(-1) * I_ch;

dotX=[x1_dot;x2_dot;x3_dot;x4_dot];
