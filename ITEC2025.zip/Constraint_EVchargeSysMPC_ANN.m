function [ineq, eq]=Constraint_EVchargeSysMPC_ANN(decisionV,d_box,X0,Yoff,Delta0,dt,controlHorizon,predictionHorizon,fSOC_Table,netParams_DySys,netParams_Obs)

    ineq=[];
    eq=[];
    
    SOCmin=0;
    SOCmax=1;
    
    V_ch_min=280;%V
    V_ch_max=420;%V
    
    I_ch_min=0;%A
    I_ch_max=125;%A
    
    V_dc_min=V_ch_min*0;%V
    V_dc_max=V_ch_max*1.8;%V
    
    decisionV=reshape(decisionV,size(decisionV,1)/controlHorizon,controlHorizon);
    U=repelem(decisionV, 1, d_box);% expand column of decisionV based on the element in d_box
    
    Delta=repmat(Delta0,1,predictionHorizon);% assume delta keep constant in the prediction horizon as we cannot obtain the disturbance data from future in the real case
    
    X(:,1)=X0;
    
    Lfdbk=eye(4);% output feedback matrix
    
    for i=1:predictionHorizon
        
        % model solving (ode4)
        [IncRate,~] = ode4_singleStep(X(:,i),U(:,i), Delta(:,i), Yoff, dt,netParams_DySys,fSOC_Table,Lfdbk);
        X(:,i+1)=X(:,i)+IncRate*dt;
    
        % output observe
        VOC=fSOC_Table({X(4,i)});
        InputMatrix=[X(1:3,i);VOC;U(:,i)];
        Z(:,i)=myANN_Obs(InputMatrix,netParams_Obs);
    
        % extract variables-----------------
        SOC=X(4,i);
        
        V_ch = Z(2,i);
        V_dc = Z(3,i);
        I_ch = Z(7,i);
    
        % constraints
        ineq=[ineq;SOC-SOCmax];
        ineq=[ineq;SOCmin-SOC];
        
        ineq=[ineq;V_ch-V_ch_max];
        ineq=[ineq;V_ch_min-V_ch];
    
        ineq=[ineq;I_ch-I_ch_max];
        ineq=[ineq;I_ch_min-I_ch];
    
        ineq=[ineq;V_dc-V_dc_max];
        ineq=[ineq;V_dc_min-V_dc];
    end
    
    ineq=[ineq;X(4,end)-SOCmax];
    ineq=[ineq;SOCmin-X(4,end)];
    
    function [IncRate,dotX] = ode4_singleStep(X, U, Delta, Yoff, h,netParams_DySys,fSOC_Table,Lfdbk)
        % k1 = f(t, X, U1, D1);
        U1 = U;           
        D1 = Delta;       
        X1 = X;
    
        VOC1 = fSOC_Table({X1(4,:)});
        InMatrix=[X1(1:3,1);VOC1;U1;D1];
        k1 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
        
        % k2 = f(t + 0.5*h, X + 0.5*h*k1, U2, D2);
        U2 = U;
        D2 = Delta;
        X2 = X + 0.5*h*k1;
        
        VOC2 = fSOC_Table({X2(4,:)});
        InMatrix=[X2(1:3,1);VOC2;U2;D2];
        k2 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
        
        % k3 = f(t + 0.5*h, X + 0.5*h*k2, U2, D2);
        U3 = U2;
        D3 = D2;
        X3 = X + 0.5*h*k2;
        
        VOC3 = fSOC_Table({X3(4,:)});
        InMatrix=[X3(1:3,1);VOC3;U3;D3];
        k3 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
    
        % k4 = f(t + h, X + h*k3, U3, D3);
        U4 = U;
        D4 = Delta;
        X4 = X + h*k3;
        
        VOC4 = fSOC_Table({X4(4,:)});
        InMatrix=[X4(1:3,1);VOC4;U4;D4];
        k4 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
    
        IncRate =  (1/6) * (k1 + 2*k2 + 2*k3 + k4);
        dotX = k1;
    end

    
    function Y_out = myANN_DySysConv(X_in, netParams)
    % Custom implementation of a feedforward propagation:
    %   X_in:  (n x N) Input matrix, N is the points numbers
    %   IW:    (H x n) Input-to-hidden weights
    %   b1:    (H x 1) Bias vector for the hidden layer
    %   LW:    (o x H) Hidden-to-output weights
    %   b2:    (o x 1) Bias vector for the output layer
    %
    % Returns: Y_out: (o x 1) Output column vector
    
        IW=netParams.IW;
        b1=netParams.b1;
        LW=netParams.LW;
        b2=netParams.b2;
    
        % [X_in,~] = removeconstantrows('apply',X_in,netParams.PSi1);
        [X_in,~] = mapminmax('apply',X_in,netParams.PSi2);
    
        % 1) Linear combination at hidden layer
        Z1 = IW * X_in + b1;      % (H x 1)
    
        % 2) Activation function at hidden layer: tansig
        A1 = tansig(Z1);         % (H x 1)
    
        % 3) Linear combination at output layer
        Z2 = LW * A1 + b2;       % (o x 1)
    
        % 4) If the output layer is purelin, then output directly: Y_out = Z2
        Y_out = Z2;
    
        Y_out = mapminmax('reverse',Y_out,netParams.PSo2);
        % Y_out = removeconstantrows('reverse',Y_out,netParams.PSo1);
    end
    
    function Y_out = myANN_DySysBat(X_in, netParams)
    % Custom implementation of a feedforward propagation:
    %   X_in:  (n x 1) Input matrix, N is the points numbers
    %   IW:    (H x n) Input-to-hidden weights
    %   b1:    (H x 1) Bias vector for the hidden layer
    %   LW:    (o x H) Hidden-to-output weights
    %   b2:    (o x 1) Bias vector for the output layer
    %
    % Returns: Y_out: (o x 1) Output column vector
    
        IW=netParams.IW;
        b1=netParams.b1;
        LW=netParams.LW;
        b2=netParams.b2;
    
        [X_in,~] = removeconstantrows('apply',X_in,netParams.PSi1);
        [X_in,~] = mapminmax('apply',X_in,netParams.PSi2);
    
        % 1) Linear combination at hidden layer
        Z1 = IW * X_in + b1;      % (H x 1)
    
        % 2) Activation function at hidden layer: tansig
        A1 = tansig(Z1);         % (H x 1)
    
        % 3) Linear combination at output layer
        Z2 = LW * A1 + b2;       % (o x 1)
    
        % 4) If the output layer is purelin, then output directly: Y_out = Z2
        Y_out = Z2;
    
        Y_out = mapminmax('reverse',Y_out,netParams.PSo2);
        Y_out = removeconstantrows('reverse',Y_out,netParams.PSo1);
    end
    
    function Y_out = myANN_Obs(X_in, netParams)
    % Custom implementation of a feedforward propagation:
    %   X_in:  (n x 1) Input matrix, N is the points numbers
    %   IW:    (H x n) Input-to-hidden weights
    %   b1:    (H x 1) Bias vector for the hidden layer
    %   LW:    (o x H) Hidden-to-output weights
    %   b2:    (o x 1) Bias vector for the output layer
    %
    % Returns: Y_out: (o x 1) Output column vector
    
        IW=netParams.IW;
        b1=netParams.b1;
        LW=netParams.LW;
        b2=netParams.b2;
    
        [X_in,~] = removeconstantrows('apply',X_in,netParams.PSi1);
        [X_in,~] = mapminmax('apply',X_in,netParams.PSi2);
    
        % 1) Linear combination at hidden layer
        Z1 = IW * X_in + b1;      % (H x 1)
    
        % 2) Activation function at hidden layer: tansig
        A1 = tansig(Z1);         % (H x 1)
    
        % 3) Linear combination at output layer
        Z2 = LW * A1 + b2;       % (o x 1)
    
        % 4) If the output layer is purelin, then output directly: Y_out = Z2
        Y_out = Z2;
    
        Y_out = mapminmax('reverse',Y_out,netParams.PSo2);
        Y_out = removeconstantrows('reverse',Y_out,netParams.PSo1);
    end
end