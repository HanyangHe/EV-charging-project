function [ineq, eq]=Constraint_EVchargeSysMPC(decisionV,d_box,X0,Delta0,CharSysParamAlgebrPart,CharSysParamDiffPart,dt,controlHorizon,predictionHorizon)

ineq=[];
eq=[];

SOCmin=0;
SOCmax=1;

V_ch_min=280;%V
V_ch_max=420;%V

I_ch_min=0;%A
I_ch_max=125;%A

V_dc_min=V_ch_min*0;%V
V_dc_max=V_ch_max*1.8;%V

decisionV=reshape(decisionV,size(decisionV,1)/controlHorizon,controlHorizon);
U=repelem(decisionV, 1, d_box);% expand column of decisionV based on the element in d_box

% U=[U U(:,end)];

Delta=repmat(Delta0,1,predictionHorizon);% assume delta keep constant in the prediction horizon as we cannot obtain the disturbance data from future in the real case

X(:,1)=X0;

for i=1:predictionHorizon
    % modeling solving (1st-order Euler)
    % Z(:,i)=AC_ChargingSystemDynModel_AlgebraicPart(X(:,i),U(:,i),CharSysParamAlgebrPart);
    % dotx=AC_ChargingSystemDynModel_DifferentialPart(X(:,i),Z(:,i),Delta(:,i),CharSysParamDiffPart);
    % X(:,i+1)=X(:,i)+dotx*dt;
    
    % modeling solving (2nd-order Euler)
    % Z(:,i)=AC_ChargingSystemDynModel_AlgebraicPart(X(:,i),U(:,i),CharSysParamAlgebrPart);
    % dotx=AC_ChargingSystemDynModel_DifferentialPart(X(:,i),Z(:,i),Delta(:,i),CharSysParamDiffPart);
    % Xnext=X(:,i)+dotx*dt;
    % 
    % Znext=AC_ChargingSystemDynModel_AlgebraicPart(Xnext,U(:,i),CharSysParamAlgebrPart);
    % dotx_next=AC_ChargingSystemDynModel_DifferentialPart(Xnext,Znext,Delta(:,i),CharSysParamDiffPart);
    % X(:,i+1)=X(:,i)+(dotx_next+dotx)/2*dt;

    % model solving (ode4)
    [IncRate,~,Z(:,i)] = ode4_singleStep(X(:,i),U(:,i), Delta(:,i), dt, CharSysParamDiffPart, CharSysParamAlgebrPart);
    X(:,i+1)=X(:,i)+IncRate*dt;

    % extract variables
    V_ch=Z(2,i);
    V_dc=Z(3,i);
    I_ch=Z(7,i);
    SOC=X(4,i);

    % Iinvx=X(1,i);
    % Iinvy=X(2,i);
    % Vinvx=Z(4,i);
    % Vinvy=Z(5,i);
    % QinvIN = Vinvx .* Iinvy - Vinvy .* Iinvx;% The input reactive power is positive
    
    % constraints
    % ineq=[ineq;Qinv_min-QinvIN];

    ineq=[ineq;SOC-SOCmax];
    ineq=[ineq;SOCmin-SOC];
    
    ineq=[ineq;V_ch-V_ch_max];
    ineq=[ineq;V_ch_min-V_ch];

    ineq=[ineq;I_ch-I_ch_max];
    ineq=[ineq;I_ch_min-I_ch];

    ineq=[ineq;V_dc-V_dc_max];
    ineq=[ineq;V_dc_min-V_dc];
end

ineq=[ineq;X(4,end)-SOCmax];
ineq=[ineq;SOCmin-X(4,end)];

    function [IncRate,dotX,Z] = ode4_singleStep(X, U, Delta, h, CharSysParamDiffPart, CharSysParamAlgebrPart)
    % k1 = f(t, X, U1, D1);
    U1 = U;           % U(t)
    D1 = Delta;       % Delta(t)
    X1=X;
    Z1 = AC_ChargingSystemDynModel_AlgebraicPart(X1,U1,CharSysParamAlgebrPart);
    k1 = AC_ChargingSystemDynModel_DifferentialPart(X1,Z1,D1,CharSysParamDiffPart);
    
    % k2 = f(t + 0.5*h, X + 0.5*h*k1, U2, D2);
    U2 = U;
    D2 = Delta;
    X2=X + 0.5*h*k1;
    Z2 = AC_ChargingSystemDynModel_AlgebraicPart(X2,U2,CharSysParamAlgebrPart);
    k2 = AC_ChargingSystemDynModel_DifferentialPart(X2,Z2,D2,CharSysParamDiffPart);
    
    % k3 = f(t + 0.5*h, X + 0.5*h*k2, U2, D2);
    U3 = U2;
    D3 = D2;
    X3=X + 0.5*h*k2;
    Z3 = AC_ChargingSystemDynModel_AlgebraicPart(X3,U3,CharSysParamAlgebrPart);
    k3 = AC_ChargingSystemDynModel_DifferentialPart(X3,Z3,D3,CharSysParamDiffPart);

    % k4 = f(t + h, X + h*k3, U3, D3);
    U4 = U;
    D4 = Delta;
    X4=X + h*k3;
    Z4 = AC_ChargingSystemDynModel_AlgebraicPart(X4,U4,CharSysParamAlgebrPart);
    k4 = AC_ChargingSystemDynModel_DifferentialPart(X4,Z4,D4,CharSysParamDiffPart);

    IncRate =  (1/6) * (k1 + 2*k2 + 2*k3 + k4);
    dotX=k1;
    Z=Z1;
    end
end