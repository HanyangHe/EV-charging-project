function cost=Objfun_EVchargeSysMPC_ANN(decisionV,d_box,deciPre,X0,Yoff,Delta0,SOC0,SOCtarget,Voc90,dt,controlHorizon,predictionHorizon,MeasureVpccMag,VpccMag0,fSOC_Table,netParams_DySys,netParams_Obs)

    w_Iac=0.1;
    w_dU=0.5;
    w_diL=0.1;
    w_charge=2;
    w_Vcb=1;
    w_SOC=4;
    w_SOCr=4;
    w_u=4;
    Alpha=4;
    
    cost=0;
    V_ch_ref=Voc90;
    
    decisionV=reshape(decisionV,size(decisionV,1)/controlHorizon,controlHorizon);
    U=repelem(decisionV, 1, d_box);% expand column of decisionV_u based on the element in d_box
    Upre=[deciPre U(:,1:end-1)];
    
    Delta=repmat(Delta0,1,predictionHorizon);
    
    X(:,1)=X0;
    xe(1,1)=0;
    
    Lfdbk=eye(4);% output feedback matrix
    
    for i=1:predictionHorizon
        
        % model solving (ode4)
        [IncRate,~] = ode4_singleStep(X(:,i),U(:,i), Delta(:,i), Yoff, dt, netParams_DySys,fSOC_Table,Lfdbk);
        X(:,i+1)=X(:,i)+IncRate*dt;
        dot_xe=X(4,i)-SOCtarget;
        xe(1,i+1)=xe(1,i)+(dot_xe)*dt;% integral error
    
        % output observe
        VOC=fSOC_Table({X(4,i)});
        InputMatrix=[X(1:3,i);VOC;U(:,i)];
        Z(:,i)=myANN_Obs(InputMatrix,netParams_Obs);
      
        % extract information
        SOC=X(4,i);

        V_oc = Z(1,i);
        V_ch = Z(2,i);
        I_ch = Z(7,i);
    
        if MeasureVpccMag==1
            VpccMag=sqrt(Delta(1,i)^2+Delta(2,i)^2);
        else
            VpccMag=VpccMag0;
        end
        m=1;
        Vdc_end=1/m*sqrt(8/3)*VpccMag;% assume Ex and Ey will give the max magnitude sqrt(Ex^2+Ey^2)=1
        d_0=0.95;
        d_end=min(V_ch_ref/Vdc_end,d_0);
    
        w=Weights_adjuster((SOC-SOC0)/(SOCtarget-SOC0),SOCtarget/SOCtarget,1,0,Alpha);
    
        % ---------state tracking------------
        cost=cost+w_SOCr*(X(4,i)-SOCtarget)^2;% track the target SOC
        cost=cost+w_SOCr*xe(1,i)^2;% integral of error
    
        % state traking at fully charge stage
        cost=cost+w_Vcb*(w)*(V_ch-V_oc)^2;% when fully charge, Vcb should be zero
        cost=cost+w*sqrt(X(1,i)^2+X(2,i)^2)*w_Iac;% reduce AC current magnitude when charging finished
    
        % tracking control for other variable
        cost=cost-w_charge*((1-w)*I_ch);% when fully charge, charging current should be zero
    
        % -------penalty of variation-------
        cost=cost+w_dU*sum((U(:,i)-Upre(:,i)).^2);% penalty of input change
        if i>1
            cost=cost+w_diL*sum((X(1:2,i)-X(1:2,i-1)).^2);% penalty of state1-2 (iL) change
        end
    
        % ------track the target U at steady state-------
        cost=cost+w_u*(w)*(sqrt(U(1,i)^2+U(2,i)^2)-1)^2;
        cost=cost+w_u*(w)*(d_end-U(3,i))^2;% track the target duty cycle
    end
    
    % terminal cost
    cost=cost+w_SOC*(X(4,end)-SOCtarget)^2;% track the target SOC
    
    function [IncRate,dotX] = ode4_singleStep(X, U, Delta, Yoff, h, netParams_DySys,fSOC_Table,Lfdbk)
        % k1 = f(t, X, U1, D1);
        U1 = U;           
        D1 = Delta;       
        X1 = X;
    
        VOC1 = fSOC_Table({X1(4,:)});
        InMatrix=[X1(1:3,1);VOC1;U1;D1];
        k1 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
        
        % k2 = f(t + 0.5*h, X + 0.5*h*k1, U2, D2);
        U2 = U;
        D2 = Delta;
        X2 = X + 0.5*h*k1;
        
        VOC2 = fSOC_Table({X2(4,:)});
        InMatrix=[X2(1:3,1);VOC2;U2;D2];
        k2 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
        
        % k3 = f(t + 0.5*h, X + 0.5*h*k2, U2, D2);
        U3 = U2;
        D3 = D2;
        X3 = X + 0.5*h*k2;
        
        VOC3 = fSOC_Table({X3(4,:)});
        InMatrix=[X3(1:3,1);VOC3;U3;D3];
        k3 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
    
        % k4 = f(t + h, X + h*k3, U3, D3);
        U4 = U;
        D4 = Delta;
        X4 = X + h*k3;
        
        VOC4 = fSOC_Table({X4(4,:)});
        InMatrix=[X4(1:3,1);VOC4;U4;D4];
        k4 = myANN_DySysConv(InMatrix,netParams_DySys)+Lfdbk*Yoff;
    
        IncRate =  (1/6) * (k1 + 2*k2 + 2*k3 + k4);
        dotX = k1;
    end

    
    function Y_out = myANN_DySysConv(X_in, netParams)
    % Custom implementation of a feedforward propagation:
    %   X_in:  (n x N) Input matrix, N is the points numbers
    %   IW:    (H x n) Input-to-hidden weights
    %   b1:    (H x 1) Bias vector for the hidden layer
    %   LW:    (o x H) Hidden-to-output weights
    %   b2:    (o x 1) Bias vector for the output layer
    %
    % Returns: Y_out: (o x 1) Output column vector
    
        IW=netParams.IW;
        b1=netParams.b1;
        LW=netParams.LW;
        b2=netParams.b2;
    
        % [X_in,~] = removeconstantrows('apply',X_in,netParams.PSi1);
        [X_in,~] = mapminmax('apply',X_in,netParams.PSi2);
    
        % 1) Linear combination at hidden layer
        Z1 = IW * X_in + b1;      % (H x 1)
    
        % 2) Activation function at hidden layer: tansig
        A1 = tansig(Z1);         % (H x 1)
    
        % 3) Linear combination at output layer
        Z2 = LW * A1 + b2;       % (o x 1)
    
        % 4) If the output layer is purelin, then output directly: Y_out = Z2
        Y_out = Z2;
    
        Y_out = mapminmax('reverse',Y_out,netParams.PSo2);
        % Y_out = removeconstantrows('reverse',Y_out,netParams.PSo1);
    end
    
    % function Y_out = myANN_DySysBat(X_in, netParams)
    % % Custom implementation of a feedforward propagation:
    % %   X_in:  (n x 1) Input matrix, N is the points numbers
    % %   IW:    (H x n) Input-to-hidden weights
    % %   b1:    (H x 1) Bias vector for the hidden layer
    % %   LW:    (o x H) Hidden-to-output weights
    % %   b2:    (o x 1) Bias vector for the output layer
    % %
    % % Returns: Y_out: (o x 1) Output column vector
    % 
    %     IW=netParams.IW;
    %     b1=netParams.b1;
    %     LW=netParams.LW;
    %     b2=netParams.b2;
    % 
    %     [X_in,~] = removeconstantrows('apply',X_in,netParams.PSi1);
    %     [X_in,~] = mapminmax('apply',X_in,netParams.PSi2);
    % 
    %     % 1) Linear combination at hidden layer
    %     Z1 = IW * X_in + b1;      % (H x 1)
    % 
    %     % 2) Activation function at hidden layer: tansig
    %     A1 = tansig(Z1);         % (H x 1)
    % 
    %     % 3) Linear combination at output layer
    %     Z2 = LW * A1 + b2;       % (o x 1)
    % 
    %     % 4) If the output layer is purelin, then output directly: Y_out = Z2
    %     Y_out = Z2;
    % 
    %     Y_out = mapminmax('reverse',Y_out,netParams.PSo2);
    %     Y_out = removeconstantrows('reverse',Y_out,netParams.PSo1);
    % end
    
    function Y_out = myANN_Obs(X_in, netParams)
    % Custom implementation of a feedforward propagation:
    %   X_in:  (n x 1) Input matrix, N is the points numbers
    %   IW:    (H x n) Input-to-hidden weights
    %   b1:    (H x 1) Bias vector for the hidden layer
    %   LW:    (o x H) Hidden-to-output weights
    %   b2:    (o x 1) Bias vector for the output layer
    %
    % Returns: Y_out: (o x 1) Output column vector
    
        IW=netParams.IW;
        b1=netParams.b1;
        LW=netParams.LW;
        b2=netParams.b2;
    
        [X_in,~] = removeconstantrows('apply',X_in,netParams.PSi1);
        [X_in,~] = mapminmax('apply',X_in,netParams.PSi2);
    
        % 1) Linear combination at hidden layer
        Z1 = IW * X_in + b1;      % (H x 1)
    
        % 2) Activation function at hidden layer: tansig
        A1 = tansig(Z1);         % (H x 1)
    
        % 3) Linear combination at output layer
        Z2 = LW * A1 + b2;       % (o x 1)
    
        % 4) If the output layer is purelin, then output directly: Y_out = Z2
        Y_out = Z2;
    
        Y_out = mapminmax('reverse',Y_out,netParams.PSo2);
        Y_out = removeconstantrows('reverse',Y_out,netParams.PSo1);
    end
end