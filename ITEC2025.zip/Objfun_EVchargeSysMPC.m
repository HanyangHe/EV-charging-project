function cost=Objfun_EVchargeSysMPC(decisionV,d_box,deciPre,X0,Delta0,SOC0,SOCtarget,Voc90,CharSysParamAlgebrPart,CharSysParamDiffPart,dt,controlHorizon,predictionHorizon,MeasureVpccMag,VpccMag0)

w_Iac=0.1;
w_dU=0.5;
w_diL=0.1;
w_charge=2;
w_Vcb=1;
w_SOC=4;
w_SOCr=4;
w_u=4;
Alpha=4;

cost=0;
V_ch_ref=Voc90;

decisionV=reshape(decisionV,size(decisionV,1)/controlHorizon,controlHorizon);
U=repelem(decisionV, 1, d_box);% expand column of decisionV_u based on the element in d_box
Upre=[deciPre U(:,1:end-1)];

Delta=repmat(Delta0,1,predictionHorizon);

X(:,1)=X0;
xe(1,1)=0;

for i=1:predictionHorizon
    % model solving (1st-order Euler)
    % Z(:,i)=AC_ChargingSystemDynModel_AlgebraicPart(X(:,i),U(:,i),CharSysParamAlgebrPart);
    % dotx=AC_ChargingSystemDynModel_DifferentialPart(X(:,i),Z(:,i),Delta(:,i),CharSysParamDiffPart);
    % X(:,i+1)=X(:,i)+dotx*dt;
    % dot_xe=X(4,i)-SOCtarget;
    % xe(1,i+1)=xe(1,i)+(dot_xe)*dt;% integral error

    % model solving (2nd-order Euler)
    % Z(:,i)=AC_ChargingSystemDynModel_AlgebraicPart(X(:,i),U(:,i),CharSysParamAlgebrPart);
    % dotx=AC_ChargingSystemDynModel_DifferentialPart(X(:,i),Z(:,i),Delta(:,i),CharSysParamDiffPart);
    % Xnext=X(:,i)+dotx*dt;
    % dot_xe=X(4,i)-SOCtarget;
    % 
    % Znext=AC_ChargingSystemDynModel_AlgebraicPart(Xnext,U(:,i),CharSysParamAlgebrPart);
    % dotx_next=AC_ChargingSystemDynModel_DifferentialPart(Xnext,Znext,Delta(:,i),CharSysParamDiffPart);
    % X(:,i+1)=X(:,i)+(dotx_next+dotx)/2*dt;
    % dot_xe_next=Xnext(4,1)-SOCtarget;
    % xe(1,i+1)=xe(1,i)+(dot_xe+dot_xe_next)/2*dt;% integral error

    % model solving (ode4)
    [IncRate,~,Z(:,i)] = ode4_singleStep(X(:,i),U(:,i), Delta(:,i), dt, CharSysParamDiffPart, CharSysParamAlgebrPart);
    X(:,i+1)=X(:,i)+IncRate*dt;
    dot_xe=X(4,i)-SOCtarget;
    xe(1,i+1)=xe(1,i)+(dot_xe)*dt;% integral error
  
    % extract information
    SOC=X(4,i);
    I_ch = Z(7,i);
    V_oc = Z(1,i);
    V_ch = Z(2,i);
    
    if MeasureVpccMag==1
    VpccMag=sqrt(Delta(1,i)^2+Delta(2,i)^2);
    else
    VpccMag=VpccMag0;
    end
    m=1;
    Vdc_end=1/m*sqrt(8/3)*VpccMag;% assume Ex and Ey will give the max magnitude sqrt(Ex^2+Ey^2)=1
    d_0=0.95;
    d_end=min(V_ch_ref/Vdc_end,d_0);

    % cost function plan 1:
    w=Weights_adjuster((SOC-SOC0)/(SOCtarget-SOC0),SOCtarget/SOCtarget,1,0,Alpha);
    
    % ---------state tracking------------
    cost=cost+w_SOCr*(X(4,i)-SOCtarget)^2;% track the target SOC
    cost=cost+w_SOCr*xe(1,i)^2;% integral of error

    % state traking at fully charge stage
    cost=cost+w_Vcb*(w)*(V_ch-V_oc)^2;% when fully charge, Vcb should be zero
    cost=cost+w*sqrt(X(1,i)^2+X(2,i)^2)*w_Iac;% reduce AC current magnitude when charging finished

    % tracking control for other variable
    cost=cost-w_charge*((1-w)*I_ch);% when fully charge, charging current should be zero

    % -------penalty of variation-------
    cost=cost+w_dU*sum((U(:,i)-Upre(:,i)).^2);% penalty of input change

    if i>1
        cost=cost+w_diL*sum((X(1:2,i)-X(1:2,i-1)).^2);% penalty of state1-2 (iL) change
    end

    % ------track the target U at steady state-------
    cost=cost+w_u*(w)*(sqrt(U(1,i)^2+U(2,i)^2)-1)^2;
    cost=cost+w_u*(w)*(d_end-U(3,i))^2;% track the target duty cycle

    % cost function plan 2:
    % Vbase=400;% PCC voltage rated value (V)
    % Sbase=50e3;% a typical EVCS power level (W)
    % Ibase=Sbase/(sqrt(3)*Vbase);% (A)
    % Xtarget=[0;0;0;SOCtarget];
    % 
    % cost=cost+norm(X(:,i)-Xtarget)*w_SOCr;
    % cost=cost+w_dU*sum((U(:,i)-Upre(:,i)).^2);% penalty of input change
    % if i>1
    %     cost=cost+w_diL*sum((X(1:2,i)-X(1:2,i-1)).^2);% penalty of state1-2 (iL) change
    % end
end

% terminal cost
cost=cost+w_SOC*(X(4,end)-SOCtarget)^2;% track the target SOC

% cost=cost+norm(X(:,i)-Xtarget)*w_SOC;

    function [IncRate,dotX,Z] = ode4_singleStep(X, U, Delta, h, CharSysParamDiffPart, CharSysParamAlgebrPart)
    % k1 = f(t, X, U1, D1);
    U1 = U;           % U(t)
    D1 = Delta;       % Delta(t)
    X1=X;
    Z1 = AC_ChargingSystemDynModel_AlgebraicPart(X1,U1,CharSysParamAlgebrPart);
    k1 = AC_ChargingSystemDynModel_DifferentialPart(X1,Z1,D1,CharSysParamDiffPart);
    
    % k2 = f(t + 0.5*h, X + 0.5*h*k1, U2, D2);
    U2 = U;
    D2 = Delta;
    X2=X + 0.5*h*k1;
    Z2 = AC_ChargingSystemDynModel_AlgebraicPart(X2,U2,CharSysParamAlgebrPart);
    k2 = AC_ChargingSystemDynModel_DifferentialPart(X2,Z2,D2,CharSysParamDiffPart);
    
    % k3 = f(t + 0.5*h, X + 0.5*h*k2, U2, D2);
    U3 = U2;
    D3 = D2;
    X3=X + 0.5*h*k2;
    Z3 = AC_ChargingSystemDynModel_AlgebraicPart(X3,U3,CharSysParamAlgebrPart);
    k3 = AC_ChargingSystemDynModel_DifferentialPart(X3,Z3,D3,CharSysParamDiffPart);

    % k4 = f(t + h, X + h*k3, U3, D3);
    U4 = U;
    D4 = Delta;
    X4=X + h*k3;
    Z4 = AC_ChargingSystemDynModel_AlgebraicPart(X4,U4,CharSysParamAlgebrPart);
    k4 = AC_ChargingSystemDynModel_DifferentialPart(X4,Z4,D4,CharSysParamDiffPart);

    IncRate =  (1/6) * (k1 + 2*k2 + 2*k3 + k4);
    dotX=k1;
    Z=Z1;
    end
end