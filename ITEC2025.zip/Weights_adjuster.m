function w=Weights_adjuster(dist,distT,k1,k0,Alpha)
% dist is the distance from initial point
% distT is the distance from the initial point to the target point
% k0 is the weight at the initial point
% k1 is the weight at the terminal point
% Alpha is the model order

dist=abs(dist);
distT=abs(distT);

w=(k1-k0)*(dist/distT).^Alpha + k0;
w=min(w,1);
w=max(w,min(k0,k1));